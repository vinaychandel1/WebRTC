const randomstring = require("randomstring");







exports.host_meeting=(req,res)=>{
    var meetingID  = randomstring.generate({
        length:9,
        charset:'numeric'
      });
      var password  = randomstring.generate({
        length:9,
        charset:'alphabetic'
      }); 
    var host_user=([{
        userName:req.body.name,
        meetingId:meetingID,
        password:password
    }])
    console.log(host_user.length);
    res.render('host_meeting',{body:host_user});
}


exports.join_meeting=(req,res)=>{
    var join_user=([{
        userName:req.body.name,
        meetingId:req.body.meetingID
        }])
        console.log(join_user)
    res.render('join_meeting',{body:join_user});
}


exports.join_meeting_link=(req,res)=>{
    console.log(req.params)
    var join_user=([{
        userName:req.body.name,
        meetingId:req.params.id
        }])
        console.log(join_user)
    res.render('join_meeting',{body:join_user});
    
}

