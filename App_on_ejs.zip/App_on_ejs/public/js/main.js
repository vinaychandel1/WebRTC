'use strict'

//Global Variables
var isConnectedToHost = false;
var isInitiator = false;
var isSuperNode = false;
var isHost = true;
var toggleScreen = false;
var toggleAudio = true;
var toggleVideo = false;

var remoteStream = null;
var callType = null;
var localStream;
var clientId;

var localPeerList = [];
var offerBufferList = [];
var answerBufferList = [];

//Finding Buttons and stuff
var localVideo = document.querySelector('#localVideo');
var progressBar = document.querySelector("#progressBar");
var startVideoCallButton = document.querySelector('#startVideoCall');
var startAudioCallButton = document.querySelector('#startAudioCall');
var toggleVideoButton = document.querySelector('#toggleVideo');
var toggleAudioButton = document.querySelector('#toggleAudio');
var requestList = document.querySelector('#requests');
var hangupButton = document.querySelector('#hangupButton');
var toggleScreenShare = document.querySelector("#toggleScreenShare");
var rname = document.querySelector('#rname');
var uname = document.querySelector('#uname');

//Setting up roomname and username
var room = rname.textContent;
if(uname.textContent === ''){
    var person = prompt("Please enter a username:", "");
    while (person == null || person == "") {
        person = prompt("Please enter a username:", "");
    }
    uname.textContent = person;
}

//Hide all the buttons
startVideoCallButton.style.display = "none";
progressBar.style.display = "none";
requestList.style.display = "none";
startAudioCallButton.style.display = "none";
hangupButton.style.display = "none";
toggleScreenShare.style.display = "none";
toggleVideoButton.style.display = "none";
toggleAudioButton.style.display = "none";

// Add click event handlers for buttons.
startVideoCallButton.addEventListener('click', startVideoCall);
startAudioCallButton.addEventListener('click', startAudioCall);
hangupButton.addEventListener('click', hangupAction);
toggleScreenShare.addEventListener('click',toggleScreenShareAction);
toggleVideoButton.addEventListener('click',toggleVideoAction);
toggleAudioButton.addEventListener('click',toggleAudioAction);
/*
function play(){    
    for (var i=0;i<localPeerList.length;i++){
        localPeerList[i].stream.getAudioTracks().forEach(t => t.enabled = true);
    }
    localPeerList[0].stream.getVideoTracks().forEach(t => t.enabled = true);
    //Send Message to everyone through signaling client
    var myObj = {type: 'streaming', userid:clientId,specific:localPeerList[0].connectionWith};
    socket.emit("message",myObj);
}
function pause()
{
    localPeerList[localPeerList.length-1].stream.getTracks().forEach(t => t.enabled = false);
}*/
//Configuring TURN and STUN servers
var pcConfig = {
    iceServers: [{
      urls: [ "stun:bn-turn1.xirsys.com" ]
   }, {
    username: "4B_0E29_cY8bXKky-MPnQp9-YEYwBGXpeEC_xvHVVG95qVaUCB0LdwqC7OrRj7abAAAAAF7Z_KR3aGl0ZXdpejEzMw==",
    credential: "3c7279be-a703-11ea-88f8-0242ac140004",
      urls: [
        "turn:bn-turn1.xirsys.com:80?transport=udp",
        "turn:bn-turn1.xirsys.com:3478?transport=udp",
        "turn:bn-turn1.xirsys.com:80?transport=tcp",
        "turn:bn-turn1.xirsys.com:3478?transport=tcp",
        "turns:bn-turn1.xirsys.com:443?transport=tcp",
        "turns:bn-turn1.xirsys.com:5349?transport=tcp"
      ]
   }]
};


//Talking with server using socket.io
var socket = io.connect();
socket.on('created', function(room,sid) {
    console.log('Created room ' + room);
    clientId = sid;
    isSuperNode = true;
    isConnectedToHost = true;
    isInitiator = true;
    startVideoCallButton.style.display = "block"
    startAudioCallButton.style.display = "block"
    hangupButton.style.display = "block"
});

socket.on('full', function(room) {
    console.log('Room ' + room + ' is full');
});

socket.on('join', function (room){
    console.log('Another peer made a request to join room ' + room);
    console.log('This peer is the initiator of room ' + room + '!');
});

socket.on('joined', function(room,sid,numClients) {
    console.log('joined: ' + room);
    isSuperNode = true;
    clientId =sid;
    hangupButton.style.display = "block"
    callAction();
});

socket.on('message',async function(message) {
    console.log('Client received message:', message);
    if(message.type === 'offer') {
        if(message.specific === clientId){
            progressBar.style.display = "block";
            var newM = Object.assign({},message);
            offerBufferList.push(newM);
            await handleOffer(offerBufferList.pop());
        }
    }else if (message.type === 'answer'){
      if(message.specific === clientId){
          var newA = Object.assign({},message);
          answerBufferList.push(newA);
          await handleAnswer(answerBufferList.pop());
      }
    }else if (message.type === 'broadcastid') {
        broadcastIdReceived(message);
    }else if (message.type === 'grantedpermission'){
        permissonGranted(message);
    }else if (message.type === 'askpermission'){
        askedPermission(message);
    }else if (message.type === 'bye'){
        handleRemoteHangup(message);
    }else if(message.type === 'streaming'){
        var nums = document.getElementById("videos");
        var listItem = nums.getElementsByTagName("div");
        for (var i=0; i < listItem.length; i++) {
            if(listItem[i].id === message.userid){
                listItem[i].getElementsByTagName('p')[0].style.background = 
                "rgb(21, 154, 128)";
            }
        }
    }else if(message.type === 'streamingstoped'){
        var nums = document.getElementById("videos");
        var listItem = nums.getElementsByTagName("div");
        for (var i=0; i < listItem.length; i++) {
            if(listItem[i].id === message.userid){
                listItem[i].getElementsByTagName('p')[0].style.background="linear-gradient(rgba(0,0,0,0.4),rgba(0,0,0,0.4))";
            }
        }
    }
        /*if(message.specific === clientId){
            var testStream;
            var nums = document.getElementById("videos");
            var listItem = nums.getElementsByTagName("video");
            var numList = [];
            for (var i=0; i < listItem.length; i++) {
                if(listItem[i].id != "localVideo"){
                    if(listItem[i].id === message.userid)
                        testStream = listItem[i].srcObject.clone();
                }
            }
            for(var i = 0;i<localPeerList.length;i++){
                if(localPeerList[i].connectionWith != message.userid){
                    localPeerList[i].stream.getVideoTracks()[0].enabled = true;
                   var trackk = testStream.getVideoTracks()[0];
                   console.log(trackk);
                   console.log(localPeerList[i].stream.getVideoTracks()[0]);
                    var videoSender = localPeerList[i].peerConnection.getSenders().find(function(s) {
                        return s.track.kind == trackk.kind;});
                     videoSender.replaceTrack(trackk);
                }
            }
        }*/
});

async function handleOffer(message){
    var kk = await doAnswer(message)
    console.log(kk);
}

async function handleAnswer(message){
    for(var i=0;i<localPeerList.length;i++){
        if(message.userid === localPeerList[i].connectionWith){
            await localPeerList[i].peerConnection.setRemoteDescription
            (new RTCSessionDescription(message));
        }
    }
}
//----Communication Functions----
start();

function start(){
    socket.emit('create or join', room,isHost);
    console.log('What to create or  join room', room);
}
function askPermission(){
    var myObj = {type: 'askpermission', roomname: room,username:uname.textContent, userid: clientId};
    socket.emit("message",myObj);
    progressBar.style.display = "block";
}

async function askedPermission(message){
    if(isInitiator && message.roomname === room){
        var li = document.createElement("li");
        li.appendChild(document.createTextNode(message.username));
        li.id = message.userid;
        requestList.appendChild(li);
        requestList.addEventListener('click', function(ev) {
        if (ev.target.tagName === 'LI' && ev.target.className != 'checked') {
                var myObj = {type: 'grantedpermission', specific: ev.target.id,callType: callType};
                socket.emit("message",myObj);
                ev.target.classList.toggle('checked');
            }
        }, false);
        //if(confirm(message.username + ' wants to join the room!')) {
        //}else{
            //TODO : Show Rejected Message
        //}
    }
}
async function permissonGranted(message){
    if(clientId === message.specific){
      isConnectedToHost = true;
      if(message.callType === "videoCall"){
        navigator.mediaDevices.getUserMedia({ video:{width:320 ,height : 240},
            audio :true }).then(function(stream){
                //toggleScreenShare.style.display = "block"
                //toggleAudioButton.style.display = "block"
                toggleVideoButton.style.display = "block"
                callType = "videoCall";
                gotStream(stream)
                broadcastId();
            }).catch(function(e) {
            alert('getUserMedia() error: ' + e);
            });
      }
      else if(message.callType === "audioCall")
      {
        navigator.mediaDevices.getUserMedia({ video:false,
            audio :true }).then(function(stream){
                gotStream(stream);
                //toggleAudioButton.style.display = "block"
                callType = "audioCall";
                broadcastId();
            }).catch(function(e) {
                alert('getUserMedia() error: ' + e);
            });
      }
    }
}
function broadcastId() {
    var myObj = {type: 'broadcastid', userid: clientId,roomname:rname.textContent,username:uname.textContent,isSuperNode:isSuperNode};
    socket.emit("message",myObj);
}

function broadcastIdReceived(message){
    if(isConnectedToHost && isSuperNode && message.isSuperNode && message.roomname === room){
        doCall(message.userid,message.username,message.isSuperNode);
    }
}

//----Button Click Functions----
function toggleAudioAction(){

}
function toggleVideoAction(){
    if(toggleVideo === false){
        toggleVideo = true;
        localStream.getVideoTracks().forEach(t => t.enabled = true);
    }else if(toggleVideo === true){
        toggleVideo = false;
        localStream.getVideoTracks().forEach(t => t.enabled = false);
    }
}
function toggleScreenShareAction(){
    if(toggleScreen === false){
        toggleScreen = true;
        enableScreenShare();
    }else if(toggleScreen === true){
        toggleScreen = false;
        disableScreenShare();
    }

}
function enableScreenShare(){
  navigator.mediaDevices.getDisplayMedia({
      video : true
    }).then(function(stream){
        //TODO : Fix the audio issue by adding both tracks
        localStream.getVideoTracks().forEach(track =>track.stop());
        var newStream = stream;
        newStream.addTrack(localStream.getAudioTracks()[0]);
        localStream = newStream;
        localVideo.srcObject = stream;
       var trackk = stream.getVideoTracks()[0]
       for(var i =0 ;i<localPeerList.length;i++){
           var videoSender = localPeerList[i].peerConnection.getSenders().find(function(s) {
               return s.track.kind == trackk.kind;});
            videoSender.replaceTrack(trackk);
       }
    })
    .catch(function(e) {
    alert('getUserMedia() error: ' + e.name);
  })
}

function disableScreenShare(){
  navigator.mediaDevices.getUserMedia({
      video:{width:320 ,height : 240}
    }).then(function(stream){
        //TODO : Fix the audio issue by adding both tracks
        var newStream = stream;
        newStream.addTrack(localStream.getAudioTracks()[0]);
        //var trackk = newStream.getVideoTracks()[0];
        for(var i =0 ;i<localPeerList.length;i++){
            localPeerList[i].stream = newStream.clone();
            var trackk =  localPeerList[i].stream.getVideoTracks()[0];
            var videoSender = localPeerList[i].peerConnection.getSenders().find(function(s) {
                return s.track.kind == trackk.kind;});
             videoSender.replaceTrack(trackk);
             localPeerList[i].stream.getTracks().forEach(t => t.enabled = false);
            }
        gotStream(newStream);
    }).catch(function(e) {
    alert('getUserMedia() error: ' + e);
  });
}
function startAudioCall(){
    navigator.mediaDevices.getUserMedia({ video:false,
        audio :true }).then(function(stream){
            gotStream(stream);
            startVideoCallButton.style.display = "none"
            startAudioCallButton.disabled = true;
            callType = "audioCall";
            requestList.style.display = "block";
        }).catch(function(e) {
            alert('getUserMedia() error: ' + e);
        });
}
function startVideoCall(){
	if (room !== '') {
        navigator.mediaDevices.getUserMedia({ video:{width:320 ,height : 240},
        audio :true }).then(function(stream){
            gotStream(stream);
            toggleScreenShare.style.display = "block"
            toggleVideoButton.style.display = "block"
            startAudioCallButton.style.display = "none"
            startVideoCallButton.disabled = true;
            callType = "videoCall";
            requestList.style.display = "block";
        }).catch(function(e) {
        alert('getUserMedia() error: ' + e);
        });
	}
}
function callAction(){
  askPermission();
}
function hangupAction(){
    if(confirm("Are you sure you want to hang up?")) {
        hangup();
        }else{
            //TODO : DO nothing really
        }
}

//PeerConnectionFunctions (Creating connections,offers,answers)
async function createPeerConnection(userid,username,isSN) {
    try {
        var obj ={};
        obj.peerConnection = new RTCPeerConnection(pcConfig);
        obj.connectionWith = userid;  
        obj.username = username;
        obj.isSuperNode = isSN;
        obj.peerConnection.ontrack = function(event){
            handleRemoteStreamAdded(event,obj);
        }
        obj.peerConnection.onremovestream = handleRemoteStreamRemoved;
        console.log('Created RTCPeerConnnection');
        return Object.assign({},obj);
    }catch (e) {
        console.log('Failed to create PeerConnection, exception: ' + e.message);
        alert('Cannot create RTCPeerConnection object.');
        return;
    }
}

async function doCall(userid,username,isSN) {
    var pc = await createPeerConnection(userid,username,isSN);
    localPeerList.push(pc);
    pc.stream = localStream.clone();
    //(pc.stream.getVideoTracks()[0], pc.stream);
    pc.stream.getTracks().forEach(track => pc.peerConnection.addTrack(track, pc.stream));
    console.log('Sending offer to peer');
    pc.peerConnection.createOffer().then(function(offer){
      pc.peerConnection.setLocalDescription(offer);
      pc.peerConnection.onicecandidate = async function(event) {
        if (event.candidate === null) {
            await sendMessage({
                type: "offer",
                userid:clientId,
                roomname : rname.textContent,
                username : uname.textContent,
                specific: pc.connectionWith,
                isSuperNode : isSuperNode,
                sdp: pc.peerConnection.localDescription.sdp
              });
              pc.stream.getTracks().forEach(t => t.enabled = false);
        } else {
          // All ICE candidates have been sent
        }
      }
    });
}

async function doAnswer(message) {
   console.log('Sending answer to peer.');
   var pc = await createPeerConnection(message.userid,message.username,message.isSuperNode);
   localPeerList.push(pc);
   try {
        pc.stream = localStream.clone();
        pc.stream.getTracks().forEach(track => pc.peerConnection.addTrack(track, pc.stream));
        //pc.peerConnection.addStream(pc.stream);
       await pc.peerConnection.setRemoteDescription(new RTCSessionDescription(message)).then(
           await pc.peerConnection.createAnswer().then(function(answer){
               pc.peerConnection.setLocalDescription(answer)
            }));
            pc.stream.getTracks().forEach(t => t.enabled = false);
            var kk = await waitForAllIce(pc);
            progressBar.style.display = "none";
            return kk;
        } catch(e){
            console.log(e);
  }
}
async function waitForAllIce(pc){
    return new Promise((fufill, reject) => {
        pc.peerConnection.onicecandidate = function(event) {
            if (event.candidate === null) {
                fufill(
                sendMessage({
                    type: "answer",
                    userid:clientId,
                    roomname : rname.textContent,
                    username : uname.textContent,
                    specific: pc.connectionWith,
                    isSuperNode : isSuperNode,
                    sdp: pc.peerConnection.localDescription.sdp
                  }))
            }else {
            }
          }
    })
}
function handleRemoteStreamAdded(event,pc) {
    if(event.streams[0]!=remoteStream){
        remoteStream = event.streams[0];
        console.log('Remote stream added.');
        var c = document.getElementById ("videos");
        var div = document.createElement("div");
        div.style.display = "inline-block"
        var v = document.createElement ("video");
        var p = document.createElement("p");
        var node = document.createTextNode(pc.username);
        p.appendChild(node);
        p.style.color = "white";
        p.style.textAlign = "center";
        p.style.marginLeft="0px";
        p.style.background="linear-gradient(rgba(0,0,0,0.4),rgba(0,0,0,0.4))";
        p.style.marginTop = "0px";
        div.id = pc.connectionWith;
        div.className = pc.isSuperNode
        v.autoplay = true;
        v.style.height="100%";
        v.style.width="100%";
        p.style.borderRadius="20px";
        v.style.borderRadius="20px";
        v.defaultMuted = true;
        c.appendChild(div);
        div.appendChild(v);
        div.appendChild(p);
        v.srcObject = remoteStream;
    }
}
function handleRemoteStreamRemoved(event) {
    console.log('Remote stream removed. Event: ', event);
}

//Helper Functions
async function sendMessage(message) {
    console.log('Client sending message: ', message);
    var ww = await socket.emit('message', message);
    return ww;
}
/*function mixVideos() {
    if(isSuperNode){
        var nums = document.getElementById("videos");
        var listItem = nums.getElementsByTagName("video");
        var numList = [];
        for (var i=0; i < listItem.length; i++) {
            if(listItem[i].id != "localVideo")
                numList.push(listItem[i]);
        }
        for(var i =0;i<localPeerList.length;i++){
            localPeerList[i].mixer.resetVideoStreams(localStream);
            for(var j=0;j<numList.length;j++){
                if(localPeerList[i].connectionWith != numList[j].id){
                    if(localPeerList[i].isSuperNode){
                        if(numList[j].className === 'false'){
                            localPeerList[i].mixer.appendStreams(numList[j].srcObject);
                        }
                    }
                    else{
                        localPeerList[i].mixer.appendStreams(numList[j].srcObject);
                    }
                }
            }
        }
    }
}*/
function gotStream(stream) {
    console.log('Adding local stream.');
    localStream = stream;
    localStream.getVideoTracks().forEach(t => t.enabled = false);
    //localStream.width = 320;
    //localStream.height = 240;
    localVideo.srcObject = localStream;
    sendMessage('got user media');
    var speechEvents = hark(localStream, {});
    //Speech Recognization Events
    speechEvents.on('speaking', function () {
        try{
            for (var i=0;i<localPeerList.length;i++){
                if(toggleVideo === true)
                    localPeerList[i].stream.getTracks().forEach(t => t.enabled = true);
                else
                    localPeerList[i].stream.getAudioTracks().forEach(t => t.enabled = true);
            }
            var myObj = {type: 'streaming', userid:clientId};
            socket.emit("message",myObj);
        }catch(e){
            console.log(e);
        }
    });

    speechEvents.on('stopped_speaking', function () {
        try{
            for (var i=0;i<localPeerList.length;i++){
                localPeerList[i].stream.getTracks().forEach(t => t.enabled = false);
            }
            var myObj = {type: 'streamingstoped', userid:clientId};
            socket.emit("message",myObj);
        }catch(e){
                console.log(e);
            }
    });
    speechEvents.on('volume_change', function (volume, threshold) {});
}

//When Window closed
window.onbeforeunload = function(e){
    var myObj = {type: 'bye', roomname: room, userid: clientId};
    sendMessage(myObj);
};
//Hangup
function hangup() {
    //console.log('Hanging up.');
    //stop();
    var myObj = {type: 'bye', roomname: room, userid: clientId};
    sendMessage(myObj);
}

function handleRemoteHangup(message) {
    console.log(message.userid + 'Session terminated..');
    var nums = document.getElementById("videos");
    var listItem = nums.getElementsByTagName("video");
    for(var i=0;i<localPeerList.length;i++){
        if(message.userid === localPeerList[i].connectionWith){
            localPeerList[i].peerConnection.close();
            localPeerList.splice(i,1);
        }
    }
    var nums = document.getElementById("videos");
    var listItem = nums.getElementsByTagName("div");
    for (var i=0; i < listItem.length; i++) {
        if(listItem[i].id === message.userid){
            listItem[i].remove();
        }
    }
    console.log(localPeerList);
    //stop();
}

function stop() {
    pc.peerConnection.close();
    pc.peerConnection = null;
}